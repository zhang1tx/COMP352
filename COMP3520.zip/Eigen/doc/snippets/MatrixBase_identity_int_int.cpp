cout << MatrixXd::Identity(4, 3) << endl;
